module.exports = {
    home: require("./home"),
    public: require("./public"),
    puzzle1: require("./puzzle1"),
    puzzle2: require("./puzzle2")
  };
  